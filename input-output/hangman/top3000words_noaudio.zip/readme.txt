*Introduction*
The file 'words.txt' contains the 3000 most common German words.
The file 'words_utf8.txt' contains the same list, but in a slightly different format. If the program you're using displays accented characters in 'words.txt' as garbage, try this file instead.

If present, the directory 'mp3' contains pronunciations of the words. If the pronunciations aren't available, go to http://germanvocab.com to download them.

*Licensing and sources*
If you create flashcards / a memrise course from this list, please mention http://germanvocab.com somewhere.

The pronunciations are by Forvo (http://forvo.com) and are licensed under a Creative Commons CC BY-NC-SA 3.0 licence (http://creativecommons.org/licenses/by-nc-sa/3.0/deed.en_GB)

The most common German words were derived from data from http://opensubtitles.org that was collated by Jörg Tiedermann and can be found at http://opus.lingfil.uu.se/OpenSubtitles2012.php

Morphological data was from http://www.danielnaber.de/morphologie/ (original source http://www.wolfganglezius.de/doku.php?id=public:cl:morphy) and is licensed under a Creative Commons CC BY-SA 3.0 licence (see http://creativecommons.org/licenses/by-sa/3.0)

*Corrupted file names*
If you're using Windows 7 and the names of the audio files are corrupted, then this is a bug in Windows. Try unzipping this file with a third party tool (e.g. http://www.7-zip.org/)

*More information*
For more information / FAQs, see http://germanvocab.com

##

This file was generated on 31 Aug 2014 08:57:32
